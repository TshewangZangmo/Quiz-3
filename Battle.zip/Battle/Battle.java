package Quiz.week3.Battle;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

/**
 * Created by zumo on 8/10/2020.
 */

public class Battle {

    public static void main(String args[]){

        Random rand=new Random();
        Scanner scan=new Scanner(System.in);
        System.out.println("******** WELCOME TO THE BATTLE FIELD!!!********");

        Player p1 = new Player1("Titan", 250, 50);
        Player p2 = new Player2("Zumo", 250, 50);
        Player p3 = new Player3("Aces", 250, 50);
        Player p4 = new Player4("Panda", 250, 50);

        ArrayList <Player> playersList=new ArrayList<Player>();
        playersList.add(p1);
        playersList.add(p2);
        playersList.add(p3);
        playersList.add(p4);

        int size=playersList.size();

        System.out.println("Here are Players: ");
        System.out.println("-----------------");
        for(int i=0; i < size ;i++) {

            System.out.println("name: "+playersList.get(i).name+" Health: "+playersList.get(i).health+" Power: "+playersList.get(i).power);
        }

        System.out.println("====================================");

        System.out.println("******Tournament Begins!!!*******");


        int count=0;
        Player playerWinner[] = new Player[2];//Player arrayList to store two winner
        //Player fight
        for(int i=0; i < size ;i++) {
            if(i==1 || i == 3){
                System.out.println("Match : "+playersList.get(i-1).name+" Vs "+playersList.get(i).name);
                playerWinner [count++] = fight(playersList.get(i-1), playersList.get(i));
                System.out.println("----------------------------------");
            }
        }
        //2Winner fight
        System.out.println("********Final Match!!!*******");
        for(int i =0; i<playerWinner.length; i++){
            if(i == 1){
                System.out.println("Final Match : "+playerWinner[i-1].name+" Vs "+playerWinner[i].name);

                fight(playerWinner[i-1],playerWinner[i]);
                System.out.println("************** THE END!************");
        }
        }
    }

    private static Player fight(Player player1, Player player2) {

        Random rand=new Random();
        Player winner;
        while(true){
            int p1= rand.nextInt(1000);
            int p2= rand.nextInt(1000);
            if(p2>p1) {
                player1.health=player1.health-player2.power;
            }else if(p2==p1){
                player1.health=player1.health-player2.power;
                player2.health=player2.health-player1.power;
            }else {
                player2.health=player2.health-player1.power;
            }

            if(player2.health==0) {
                winner = player1;
                System.out.println("Winner is: "+player1.name);
                break;
            }
            if(player1.health==0) {
                winner = player2;
                System.out.println("winner is: "+player2.name);
                break;
            }
        }
        return winner;

    }
}
