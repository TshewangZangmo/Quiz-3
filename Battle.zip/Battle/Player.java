package Quiz.week3.Battle;

/**
 * Created by zumo on 8/12/2020.
 */
class Player{
    public String name;
    public int health;
    public int power;


    Player(String name,int health,int power) {
        this.name=name;
        this.health=health;
        this.power=power;
    }
}

class Player1 extends Player{

    Player1(String name, int health, int power) {
        super(name, health, power);
    }
}
class Player2 extends Player{

    Player2(String name, int health, int power) {
        super(name, health, power);
    }
}
class Player3 extends Player{

    Player3(String name, int health, int power) {
        super(name, health, power);
    }
}
class Player4 extends Player{

    Player4(String name, int health, int power) {
        super(name, health, power);
    }
}
