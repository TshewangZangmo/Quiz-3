package Quiz.week3.Lottery;

import java.util.ArrayList;
import java.util.Random;

/**
 * Created by zumo on 8/17/2020.
 */
public class Player {

    public ArrayList<Integer> createUsers() {

            ArrayList<Integer> users=new ArrayList<Integer>();
            for(int i=1;i<=10;i++){
                users.add(i);
            }
            return users;
    }


    public ArrayList<Integer> generateRandom() {
        ArrayList<Integer> arrayRandom=new ArrayList<Integer>();
        Random rand = new Random();

        for (int i=0; i<10; i++)
        {
            Integer r = rand.nextInt(1000);
            arrayRandom.add(r);
        }
        return arrayRandom;
    }



}






