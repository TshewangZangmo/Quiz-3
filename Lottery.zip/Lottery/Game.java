package Quiz.week3.Lottery;

import java.util.ArrayList;
import java.util.Random;

/**
 * Created by zumo on 8/18/2020.
 */
public class Game {
    public static void main(String args[]) {
        Random rand=new Random();
        Player list = new Player();

        System.out.println("********* WELCOME TO THE LOTTERY GAME!**********");
        System.out.println("--------------------------------------------");
        ArrayList<Integer> playerList;
        playerList = list.createUsers();//Creates 10 Users
         //System.out.println(playerList);

        //Creating 10 random numbers for each 10 Users
        System.out.println("Here are the list of the users with the 10 random numbers from 1-1000: ");
        System.out.println("----------------------------------------------------------");
        ArrayList<Integer> randomUserNumber=new ArrayList<Integer>();

        for (Integer integer : playerList) {
               randomUserNumber=list.generateRandom();
            System.out.println("Player"+integer+" "+randomUserNumber);//printing players and its list

        }
        System.out.println("-----------------------------------------------------------");

        //ArrayList<Integer> matchFound;
        while(true){
            int lotteryNum=(int)rand.nextInt(1000);// generate one lucky random number
            System.out.println("Today's Lucky Number is: "+lotteryNum);

            for(int i=0; i<playerList.size();i++){
                if(lotteryNum==randomUserNumber.get(i)){
                    randomUserNumber.remove(i) ;
                    System.out.println("remove");
                }
                if(randomUserNumber.isEmpty()){
                    System.out.println(playerList.get(i));
                    System.out.println("get winner");
                    break;
                }
            }


        }

    }


}